<?php
namespace App\Http\Controllers\Core;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use App\User;
use App\Office;
use App\Staff;
use App\OfficeLevel;
use App\StaffBankAcc;
use App\Bank;
use App\Status;
use App\Unit;
use App\Department;
use App\DepartmentRole;
use App\Guarantor;
use App\Level;
use App\Position;
use App\ResumptionType;
use App\Document;
use App\DocStorage;
use App\WorkExperience;
use App\EducationType;
use App\Qualification;
use App\Classe;
use App\Education;
use App\NextOfKin;
use App\EmergencyContact;

class CreateStaffClass extends Controller{

    public function __construct(){

    }

    //Personal Infos

    //nextofkins

}



